package com.raven.event;

import java.awt.Component;

public interface EventMenu {

    public boolean menuPressed(Component com, boolean open);
}
